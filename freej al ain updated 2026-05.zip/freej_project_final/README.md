# Freej Al Ain Restaurant Bot

## Setup
1. `npm install`
2. Create `.env` from `.env.example`
3. `npm start`

## Structure
Full project with `src` folder containing controllers, services, and utils.

module.exports = {
  validateWhatsAppWebhook: (body) => body.object && body.entry && body.entry[0].changes[0].value.messages
};

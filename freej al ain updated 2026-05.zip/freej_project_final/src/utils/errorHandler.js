module.exports = {
  handleError: (err, res) => {
    console.error(err);
    if (res) res.status(500).json({ error: 'Internal Server Error' });
  }
};

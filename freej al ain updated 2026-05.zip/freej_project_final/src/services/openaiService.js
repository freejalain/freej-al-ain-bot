const axios = require('axios');
const config = require('../config');
const restaurantData = require('../utils/restaurantData');

const getAIResponse = async (userMessage, session) => {
  const systemPrompt = `
You are the assistant for "Freej Al Ain Restaurant".
Tone: Emirati Arabic, friendly, sales-oriented.
Menu: ${JSON.stringify(restaurantData.menu)}
Rules: Offer upsell (${restaurantData.upsell.message_ar}) then combo (${restaurantData.combo.message_ar}) once.
Current Order: ${JSON.stringify(session.order)}
`;
  const response = await axios.post('https://api.openai.com/v1/chat/completions', {
    model: config.openai.model,
    messages: [{ role: 'system', content: systemPrompt }, ...session.history, { role: 'user', content: userMessage }]
  }, { headers: { 'Authorization': `Bearer ${config.openai.apiKey}` } });
  return response.data.choices[0].message.content;
};

module.exports = { getAIResponse };
